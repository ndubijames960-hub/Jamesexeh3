package com.example.whatsappantidelete

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class WhatsAppNotificationListener : NotificationListenerService() {
    companion object {
        const val PREFS = "saved_whatsapp_notifications"
        const val KEY_MESSAGES = "messages"
        private const val WHATSAPP_PACKAGE = "com.whatsapp"
        private const val WHATSAPP_BUSINESS_PACKAGE = "com.whatsapp.w4b"
        private const val MAX_CHARS = 60000
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != WHATSAPP_PACKAGE &&
            sbn.packageName != WHATSAPP_BUSINESS_PACKAGE) return

        val extras = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim()
            ?.takeIf { it.isNotBlank() }
            ?: extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()

        if (title.isBlank() && text.isBlank()) return
        // Avoid saving empty/group-summary notifications.
        if (sbn.notification.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
            .format(Date(sbn.postTime))
        val record = "[$time]\n$title\n$text"
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val old = prefs.getString(KEY_MESSAGES, "").orEmpty()
        // Skip immediate duplicate notification updates.
        if (old.contains(record)) return
        val updated = if (old.isBlank()) record else "$old\n---\n$record"
        prefs.edit().putString(KEY_MESSAGES, updated.takeLast(MAX_CHARS)).apply()
    }
}
