package com.example.whatsappantidelete

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
        }

        val title = TextView(this).apply {
            text = "WhatsApp Anti-Delete"
            textSize = 25f
            gravity = Gravity.CENTER
        }
        root.addView(title, ViewGroup.LayoutParams(-1, -2))

        val info = TextView(this).apply {
            text = "Saves WhatsApp message text shown in notifications. It cannot retrieve messages from before installation or recover every photo/video."
            textSize = 15f
            setPadding(0, 18, 0, 18)
        }
        root.addView(info)

        val enable = Button(this).apply {
            text = "1. Enable notification access"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }
        root.addView(enable, ViewGroup.LayoutParams(-1, -2))

        val refresh = Button(this).apply {
            text = "2. Refresh saved messages"
            setOnClickListener { showSaved() }
        }
        root.addView(refresh, ViewGroup.LayoutParams(-1, -2))

        val clear = Button(this).apply {
            text = "Clear saved history"
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Clear history?")
                    .setMessage("This permanently deletes saved messages from this app.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Clear") { _, _ ->
                        getSharedPreferences(WhatsAppNotificationListener.PREFS, MODE_PRIVATE)
                            .edit().remove(WhatsAppNotificationListener.KEY_MESSAGES).apply()
                        showSaved()
                    }.show()
            }
        }
        root.addView(clear, ViewGroup.LayoutParams(-1, -2))

        val scroll = ScrollView(this)
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 12, 0, 0)
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        showSaved()
    }

    override fun onResume() {
        super.onResume()
        if (::list.isInitialized) showSaved()
    }

    private fun showSaved() {
        list.removeAllViews()
        val prefs = getSharedPreferences(WhatsAppNotificationListener.PREFS, MODE_PRIVATE)
        val entries = prefs.getString(WhatsAppNotificationListener.KEY_MESSAGES, "")!!
            .split("\n---\n").filter { it.isNotBlank() }.asReversed()
        if (entries.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "No saved messages yet. Enable notification access, then wait for new WhatsApp notifications."
                textSize = 16f
                setPadding(0, 12, 0, 12)
            })
        } else {
            entries.forEach { entry ->
                list.addView(TextView(this).apply {
                    text = entry
                    textSize = 15f
                    setPadding(10, 12, 10, 12)
                })
                val divider = android.view.View(this).apply {
                    setBackgroundColor(0xFFDDDDDD.toInt())
                }
                list.addView(divider, LinearLayout.LayoutParams(-1, 1))
            }
        }
    }
}
