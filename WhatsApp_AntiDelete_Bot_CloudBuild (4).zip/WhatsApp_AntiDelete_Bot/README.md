# WhatsApp Anti-Delete Bot (Android)

A small Android Studio project that stores text shown in WhatsApp notifications on this device.

## Build and install
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the extracted `WhatsApp_AntiDelete_Bot` folder.
4. Allow Gradle to sync and install any requested Android SDK components.
5. Connect your Android phone with USB debugging enabled, or use **Build > Build APK(s)**.
6. Install the APK on your phone.
7. Open **WhatsApp Anti-Delete**.
8. Tap **Enable notification access** and enable access for this app in Android Settings.
9. Send/receive a new WhatsApp message that creates a notification, then tap **Refresh saved messages**.

## Important limitations
- This is not an official WhatsApp bot and does not pair through WhatsApp Web or scan a QR code.
- Android notification access is required. The app can only save content that WhatsApp exposes in notifications.
- It cannot recover old deleted messages or notifications that were never accessible.
- Photo/video recovery is not guaranteed; notification text alone cannot restore the original media file.
- WhatsApp settings such as muted chats, disabled message previews, and some notification formats can prevent text from being captured.
- Saved notification content is stored locally on the phone. Keep your phone secure and only use this for messages you are allowed to access.
